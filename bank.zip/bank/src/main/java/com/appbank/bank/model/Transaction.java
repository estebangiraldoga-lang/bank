package com.appbank.bank.model;

import java.time.LocalDateTime;

public class Transaction {
    private String type;
    private Money amount;
    private String account;
    private LocalDeteTime timestamp;
//constructor

    public Transaction(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    
//constructor
    public Transaction(String type, Money amount, String account) {
        this.type = type;
        this.amount = amount;
        this.account = account;
    }


//getter and assets 

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Money getAmount() {
        return amount;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public LocalDeteTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDeteTime timestamp) {
        this.timestamp = timestamp;
    }
    

}
